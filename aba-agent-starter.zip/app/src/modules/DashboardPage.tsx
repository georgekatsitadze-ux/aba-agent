export default function DashboardPage(){
  return (
    <div>
      <h2>Welcome to the Dashboard</h2>
      <p>Quick links and KPIs will go here.</p>
    </div>
  );
}