#!/usr/bin/env python3
"""
Minimal agent orchestrator.
- Plans tasks from /agent/tasks/*.yaml
- Generates/edits code in /app and /server (using provider LLMs you configure)
- Runs tests via Playwright and reports status
"""

import os, sys, subprocess, pathlib, glob, json, datetime

# ---- Configuration ----
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
REPO_ROOT = pathlib.Path(__file__).resolve().parents[1]
TASK_DIR = REPO_ROOT / "agent" / "tasks"
REPORTS_DIR = REPO_ROOT / "agent" / "reports"
REPORTS_DIR.mkdir(parents=True, exist_ok=True)

def sh(cmd, cwd=None, check=True):
    print(f"$ {' '.join(cmd)}")
    return subprocess.run(cmd, cwd=cwd or REPO_ROOT, check=check)

def run_tests():
    try:
        sh(["npm", "ci"], cwd=REPO_ROOT / "app")
        sh(["npx", "playwright", "install", "--with-deps"], cwd=REPO_ROOT / "app")
        sh(["npm", "test", "--", "--reporter=line"], cwd=REPO_ROOT / "app")
        return True, "Playwright tests passed."
    except subprocess.CalledProcessError as e:
        return False, f"Tests failed with code {e.returncode}."

def plan_and_generate():
    """
    Placeholder: this is where you'd call your LLM(s) to:
      - Read tasks/*.yaml
      - Update files in /app and /server
      - Create branches and commits
    For now we simulate a trivial change so you can see the loop working.
    """
    example_file = REPO_ROOT / "app" / "src" / "modules" / "DashboardPage.tsx"
    example_file.write_text((example_file.read_text() \
        .replace("Welcome to the Dashboard", "Welcome to the Dashboard 🚀")))
    sh(["git", "add", "." ])
    sh(["git", "commit", "-m", "chore(agent): trivial change to prove loop"], check=False)

def main():
    ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    print(f"[agent] run at {ts}")
    plan_and_generate()
    ok, msg = run_tests()
    summary = {
        "timestamp": ts,
        "tests_ok": ok,
        "message": msg,
    }
    (REPORTS_DIR / "latest.json").write_text(json.dumps(summary, indent=2))
    print("[agent] summary:", json.dumps(summary))
    return 0 if ok else 1

if __name__ == "__main__":
    sys.exit(main())
